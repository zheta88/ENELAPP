from django.apps import AppConfig


class WebserviceConfig(AppConfig):
    name = 'webservice'
