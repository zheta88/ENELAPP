from django import forms
from pqr.models import Pqr

class FormRegistroPQR_WS(forms.ModelForm):
	class Meta:
		model = Pqr
		fields = ['codigo','nombre','municipio','vereda']