from django.urls import path
from . import views

urlpatterns = [
	path('pqr/post/', views.post, name='servicio-post'),
]