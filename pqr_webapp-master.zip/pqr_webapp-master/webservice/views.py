from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt, csrf_protect
from decimal import *
from django.conf import settings 
from django.core.mail import send_mail
from .forms import FormRegistroPQR_WS
from pqr.models import Pqr
from PQRS.methods import enviarCorreo,pqrsCercanas

@csrf_exempt
def post(request):
	if request.method == "POST":
		codigo = request.POST.get("codigo", "")
		nombre = request.POST.get("nombre", "")
		municipio = request.POST.get("municipio", "")
		vereda = request.POST.get("vereda", "")
		latitud = Decimal(request.POST.get("latitud", ""))
		longitud = Decimal(request.POST.get("longitud", ""))
		try:
			pqr = Pqr(codigo=codigo, nombre=nombre,municipio=municipio,vereda=vereda,latitud=latitud,longitud=longitud)
			pqr.save()
			textoEmail = pqrsCercanas(codigo,latitud,longitud)
			if textoEmail != None:
				enviarCorreo(codigo,textoEmail)

		except:
			return HttpResponse("No se ha podido guardar la PQR")
	else:
		return HttpResponse("PQR no guardada. No se ha recibido un POST.")

	return HttpResponse("PQR guardada correctamente! ")