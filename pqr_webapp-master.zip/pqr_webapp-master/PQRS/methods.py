from django.conf import settings 
from django.core.mail import send_mail,EmailMultiAlternatives
from math import sin, cos, sqrt, atan2, radians
from django.db.models import Q
from decimal import *
from pqr.models import Pqr

def enviarCorreo(codigoCreado,codigosCercanos):
	subject = 'PQR Nueva'
	message = f'La PQR {codigoCreado} tiene cercanía con las siguientes PQRS:'
	message += codigosCercanos
	email_from = settings.EMAIL_HOST_USER
	recipient_list = ["anderson.sarmiento@enel.com","zullytamayom@gmail.com","miguel.chuquin@enel.com"]
	msg = EmailMultiAlternatives( subject, message, email_from, recipient_list )
	#msg.attach_alternative(message)
	msg.content_subtype = "html"
	msg.send()

def pqrsCercanas(codigo,lat,lon):
	coordRange = Decimal(.01)#Aprox. 1.11 Kms en line recta. Si los puntos estan en diagonal aprox. 1.57Kms
	lat_inf,lat_sup = lat-coordRange,lat+coordRange
	lon_inf,lon_sup = lon-coordRange,lon+coordRange
	pqrsCercanos = Pqr.objects.filter(latitud__gte=lat_inf,latitud__lte=lat_sup,longitud__gte=lon_inf,longitud__lte=lon_sup).exclude(codigo=codigo)
	if not pqrsCercanos:
		return None
	textoCodigos = "<table>"
	textoCodigos += "<tr><th><b>Código</b></b></th><th><b>Nombre</b></th><th><b>Municipio</b></th><th><b>Vereda</b></th><th><b>Latitud</b></th><th><b>Longitud</b></th><th><b>Distancia</b></th></tr>"
	for pqrs in pqrsCercanos:
		distancia = calcularDistancia(lat,pqrs.latitud,lon,pqrs.longitud)
		#Se filtran los puntos por encima
		if distancia <= Decimal(1.0):
			textoCodigos += "<tr>"
			textoCodigos += "<td>" + pqrs.codigo + "</td>"
			textoCodigos += "<td>" + pqrs.nombre + "</td>"
			textoCodigos += "<td>" + pqrs.municipio + "</td>"
			textoCodigos += "<td>" + pqrs.vereda + "</td>"
			textoCodigos += "<td>" + str(pqrs.latitud) + "</td>"
			textoCodigos += "<td>" + str(pqrs.longitud) + "</td>"
			textoCodigos += "<td>" + str(round(distancia,2)) + " Km</td>"
			textoCodigos += "</tr>"

	textoCodigos += "</table>"
	return textoCodigos

def calcularDistancia(lat1,lat2,lon1,lon2):
	rTierra = 6373.0

	lat1,lat2,lon1,lon2 = radians(lat1),radians(lat2),radians(lon1),radians(lon2)

	distanciaLon = lon2 - lon1
	distanciaLat = lat2 - lat1

	a = sin(distanciaLat / 2)**2 + cos(lat1) * cos(lat2) * sin(distanciaLon / 2)**2
	c = 2 * atan2(sqrt(a), sqrt(1 - a))

	return rTierra * c