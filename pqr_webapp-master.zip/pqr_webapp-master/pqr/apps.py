from django.apps import AppConfig


class PqrConfig(AppConfig):
    name = 'pqr'
