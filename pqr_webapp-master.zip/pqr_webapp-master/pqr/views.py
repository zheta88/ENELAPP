from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import (
	ListView, 
	DetailView, 
	CreateView,
	UpdateView,
	DeleteView
)
from .models import Pqr

def home(request):
	context = {
		'posts': Pqr.objects.all()
	}
	return render(request, 'pqr/home.html', context)

class VistaListPqr(ListView):
	model = Pqr
	template_name = 'pqr/home.html'# <app>/<model>_<viewtype>.html
	context_object_name = 'posts'
	ordering = ['-id']
	paginate_by = 10

class DetalleListPqr(LoginRequiredMixin,DetailView):
	model = Pqr
	template_name = 'pqr/pqr_detalle.html'

class CrearListPqr(LoginRequiredMixin,CreateView):
	model = Pqr
	fields = ['codigo','nombre','municipio','vereda']

	def form_valid(self, form):
		form.instance.autor = self.request.user
		return super().form_valid(form)

class ActualizarListPqr(LoginRequiredMixin,UserPassesTestMixin,UpdateView):
	model = Pqr
	fields = ['codigo','nombre','municipio','vereda']

	def form_valid(self, form):
		form.instance.autor = self.request.user
		return super().form_valid(form)

	def test_func(self):
		post = self.get_object()
		if self.request.user == post.autor:
			return True
		return False

class EliminarListPqr(LoginRequiredMixin,UserPassesTestMixin,DeleteView):
	model = Pqr
	template_name = 'pqr/pqr_confirmar_borrado.html'
	success_url = '/'

	def test_func(self):
		pqr = self.get_object()
		if self.request.user == pqr.autor:
			return True
		return False

def post(request):
	return HttpResponse('<h1>Post request</h1>')

def get(request):
	return HttpResponse('<h1>Get Request</h1>')
