from django.urls import path
from .views import (
	VistaListPqr,
	DetalleListPqr,
	CrearListPqr,
	ActualizarListPqr,
	EliminarListPqr
)
from . import views

urlpatterns = [
	path('', VistaListPqr.as_view(), name='pqr-home'),
	path('detalle/<int:pk>/', DetalleListPqr.as_view(), name='pqr-detalle'),
	path('actualizar/<int:pk>/', ActualizarListPqr.as_view(), name='pqr-actualizar'),
	path('eliminar/<int:pk>/', EliminarListPqr.as_view(), name='pqr-eliminar'),
	path('nuevo/', CrearListPqr.as_view(), name='pqr-crear'),
	path('post/', views.post, name='pqr-post'),
	path('get/', views.get, name='pqr-get'),
]