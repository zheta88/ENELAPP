from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse

class Pqr(models.Model):
	codigo = models.CharField(max_length=50)
	nombre = models.TextField()
	municipio = models.CharField(max_length=50)
	vereda = models.CharField(max_length=50)
	latitud = models.DecimalField(max_digits=10, decimal_places=8, default=None)
	longitud = models.DecimalField(max_digits=11, decimal_places=8, default=None)
	fecha_creacion = models.DateTimeField(default=timezone.now)
	#autor = models.ForeignKey(User, on_delete=models.CASCADE, default=User.objects.first())

	def __str__(self):
		return self.nombre

	def get_absolute_url(self):
		return reverse('pqr-detalle', kwargs={'pk':self.pk})