from django.contrib import admin
from .models import Pqr

admin.site.register(Pqr)
