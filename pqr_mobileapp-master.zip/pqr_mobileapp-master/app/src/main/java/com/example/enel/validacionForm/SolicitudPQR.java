package com.example.enel.validacionForm;

import android.widget.EditText;

public class SolicitudPQR {
    EditText codigoPQR;
    EditText nombreProyecto;
    EditText municipio;
    EditText vereda;

    public SolicitudPQR(EditText... campos){
        codigoPQR = campos[0];
        nombreProyecto = campos[1];
        municipio = campos[2];
        vereda = campos[3];
    }

    private boolean validarCodPQR(){
        String codPQR = codigoPQR.getText().toString();
        if(codPQR.isEmpty()){
            adjuntarErrorCampo(codigoPQR,"Se debe incluir un código de la PQR");
            return false;
        }

        return true;
    }

    private boolean validarNombrePro(){
        String nombreProyecto = this.nombreProyecto.getText().toString();
        if(nombreProyecto.isEmpty()){
            adjuntarErrorCampo(this.nombreProyecto,"Se debe incluir el nombre del proyecto");
            return false;
        }

        return true;
    }

    private boolean validarMunicipio(){
        String municipio = this.municipio.getText().toString();
        if(municipio.isEmpty()){
            adjuntarErrorCampo(this.municipio,"Se debe incluir el nombre del municipio");
            return false;
        }
        return true;
    }

    private boolean validarVereda(){
        String vereda = this.vereda.getText().toString();
        if(vereda.isEmpty()){
            adjuntarErrorCampo(this.vereda,"Se debe incluir el nombre de la vereda");
            return false;
        }
        return true;
    }

    private void adjuntarErrorCampo(EditText campo,String mensaje){
        campo.requestFocus();
        campo.setError(mensaje);
    }

    public boolean validarForm(){
        if (!validarCodPQR() || !validarNombrePro() || !validarMunicipio() || !validarVereda()){
            return false;
        }

        return true;
    }
}
