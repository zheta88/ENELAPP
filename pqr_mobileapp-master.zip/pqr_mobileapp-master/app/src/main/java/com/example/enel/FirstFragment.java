package com.example.enel;

import android.app.Activity;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentResultListener;
import androidx.navigation.fragment.NavHostFragment;

import com.example.enel.validacionForm.SolicitudPQR;

import java.util.Map;

public class FirstFragment extends Fragment {

    EditText codigoPR;
    EditText nombreProyecto;
    EditText municipio;
    EditText vereda;

    public interface onUpdateLocation {
        public Location setLonLat();
    }
    public onUpdateLocation locationReceiver;

    @Override
    public void onAttach(Activity activity){
        super.onAttach(activity);
        if(activity instanceof onUpdateLocation) {
            locationReceiver = (onUpdateLocation) activity;
        } else {
            throw new IllegalArgumentException("Containing Activity must implement onUpdateLocation");
        }
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        //Location loc = locationReceiver.setLonLat();


        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        //TextView txtLat = (TextView) view.findViewById(R.id.textView);
        //txtLat.setText("Latitude:" + loc.getLatitude()+ ", Longitude:" + loc.getLongitude());

        codigoPR = (EditText)view.findViewById(R.id.codigoPQR);
        nombreProyecto = (EditText)view.findViewById(R.id.nombreProyecto);
        municipio = (EditText)view.findViewById(R.id.municipio);
        vereda = (EditText)view.findViewById(R.id.vereda);

        Map pqrFields = ((MainActivity)getActivity()).getPqrFields();
        if(pqrFields.get("codigoPqr") != null){
            codigoPR.setText(pqrFields.get("codigoPqr").toString());
            nombreProyecto.setText(pqrFields.get("nombreProyecto").toString());
            municipio.setText(pqrFields.get("municipioProyecto").toString());
            vereda.setText(pqrFields.get("veredaProyecto").toString());
        }

        return view;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.button_first).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SolicitudPQR validacionForm = new SolicitudPQR(codigoPR,nombreProyecto,municipio,vereda);
                if(validacionForm.validarForm()) {
                    // Send values of the form to the fragment manager
                    Bundle pqrInfoBundle = new Bundle();
                    pqrInfoBundle.putString( "codigoPQR", codigoPR.getText().toString());
                    pqrInfoBundle.putString( "nombreProyecto", nombreProyecto.getText().toString());
                    pqrInfoBundle.putString( "municipio", municipio.getText().toString());
                    pqrInfoBundle.putString( "vereda", vereda.getText().toString());
                    getParentFragmentManager().setFragmentResult("requestKey", pqrInfoBundle);
                    // Navigate
                    NavHostFragment.findNavController(FirstFragment.this)
                            .navigate(R.id.action_FirstFragment_to_SecondFragment);
                }
            }
        });
    }

}