package com.example.enel;

import android.app.Activity;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RemoteViews;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentResultListener;
import androidx.navigation.fragment.NavHostFragment;

import org.osmdroid.config.Configuration;
import org.osmdroid.events.MapEventsReceiver;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.MapEventsOverlay;
import org.osmdroid.views.overlay.Marker;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class SecondFragment extends Fragment {
    String codigoPR;
    String nombreProyecto;
    String municipio;
    String vereda;
    Marker startMarker;
    Button btnEnviar;
    boolean requestSent = false;

    public interface onUpdateLocation {
        Location setLonLat();
    }

    public onUpdateLocation locationReceiver;

    @Override
    public void onAttach(Activity activity){
        super.onAttach(activity);
        if(activity instanceof onUpdateLocation){
            locationReceiver = (onUpdateLocation) activity;
        } else {
            throw new IllegalArgumentException("Illegal argument Exception!");
        }
    }

    MapView myOpenMapView;
    MapController myMapController;
    double latitude, longitude;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        super.onCreate(savedInstanceState);
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_second, container, false);
        // Obtener posición actual
        Location location = locationReceiver.setLonLat();
        if(location != null){
            setPqrLatLon(location.getLatitude(), location.getLongitude());
        } else {
            new SweetAlertDialog(
                    ((MainActivity)getActivity()), SweetAlertDialog.WARNING_TYPE)
                    .setTitleText("Advertencia")
                    .setContentText("No fue posible acceder a la geo-localización del dispositivo. Por lo tanto se asignará la localización por defecto.")
                    .setConfirmText("Aceptar")
                    .show();
            setPqrLatLon(4.6321912412080195, -74.46308434009552);
        }

        // Obtener vista del mapa OSM
        myOpenMapView = (MapView) view.findViewById(R.id.openmapview);
        Configuration.getInstance().setUserAgentValue(BuildConfig.APPLICATION_ID);
        drawMap();
        setupGestureListener();
        drawMarker(new GeoPoint(latitude,longitude));

        // Define evento del botón Enviar
        btnEnviar = (Button) view.findViewById(R.id.button_enviar);
        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnEnviar.setEnabled(false);
                System.out.println("Latitude: " + latitude + ", Longitude: " + longitude);
                System.out.println("Este es el código PQR: " + codigoPR);
                ((MainActivity)getActivity()).savePQRS(codigoPR,nombreProyecto,municipio,vereda,String.valueOf(latitude),String.valueOf(longitude));
                //NavHostFragment.findNavController(SecondFragment.this)
                //        .navigate(R.id.action_SecondFragment_to_FirstFragment);
                Button btnVolver = (Button) view.findViewById(R.id.button_second);
                btnVolver.setText("Nuevo PQR");
                ((MainActivity)getActivity()).setPqrFields(null,null,null,null);
            }
        });

        // Escucha las actualizaciones a fragment manager
        getParentFragmentManager().setFragmentResultListener("requestKey", this, new FragmentResultListener() {
            @Override
            public void onFragmentResult(@NonNull String requestKey, @NonNull Bundle result) {
                codigoPR = result.getString("codigoPQR");
                nombreProyecto = result.getString("nombreProyecto");
                municipio = result.getString("municipio");
                vereda = result.getString("vereda");
                ((MainActivity)getActivity()).setPqrFields(codigoPR,nombreProyecto,municipio,vereda);
            }
        });

        return view;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.button_second).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_FirstFragment);
            }
        });
    }

    public void drawMap() {
        //OpenStreetMapTileProviderConstants.setUserAgentValue(BuildConfig.APPLICATION_ID);
        //Configuration.getInstance().setUserAgentValue(...)
        GeoPoint locPoint = new GeoPoint(latitude,longitude);
        //myOpenMapView = (MapView) getView().findViewById(R.id.openmapview);

        myOpenMapView.setTileSource(TileSourceFactory.MAPNIK);
        myOpenMapView.setBuiltInZoomControls(true);
        myMapController = (MapController) myOpenMapView.getController();
        myMapController.setCenter(locPoint);
        myMapController.setZoom(18);

        myOpenMapView.setMultiTouchControls(true);
    }

    private void setupGestureListener() {
        MapEventsReceiver mReceive = new MapEventsReceiver() {
            @Override
            public boolean singleTapConfirmedHelper(GeoPoint p) {
                double latitudeTap = p.getLatitude();
                double longitudeTap = p.getLongitude();
                System.out.println("Single tap! on lat:" + Double.toString(latitudeTap) + " Lon: " + Double.toString(longitudeTap));

                return false;
            }

            @Override
            public boolean longPressHelper(GeoPoint p) {
                double latitudeTap = p.getLatitude();
                double longitudeTap = p.getLongitude();
                System.out.println("Long press do! on lat:" + Double.toString(latitudeTap) + " Lon: " + Double.toString(longitudeTap));
                myOpenMapView.getOverlays().remove(startMarker);
                drawMarker(p);
                setPqrLatLon(latitudeTap, longitudeTap);
                return false;
            }
        };
        MapEventsOverlay OverlayEvents = new MapEventsOverlay(((MainActivity)getActivity()), mReceive);
        myOpenMapView.getOverlays().add(OverlayEvents);
    }

    public void drawMarker(GeoPoint p) {
        startMarker = new Marker(myOpenMapView);
        startMarker.setPosition(p);
        startMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);

        myOpenMapView.getOverlays().add(startMarker);
        myOpenMapView.invalidate();
    }

    public void setPqrLatLon(double lat, double lon){
        latitude = lat;
        longitude = lon;
    }
}